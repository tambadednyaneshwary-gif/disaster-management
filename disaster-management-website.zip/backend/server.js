const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const Report = require('./models/Report');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/disasterdb', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('MongoDB connected'))
  .catch(err => console.error(err));

app.post('/api/report', async (req, res) => {
  try {
    const newReport = new Report(req.body);
    await newReport.save();
    res.status(201).send('Report saved');
  } catch (err) {
    res.status(400).send('Error saving report');
  }
});

app.get('/api/reports', async (req, res) => {
  const reports = await Report.find();
  res.json(reports);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
